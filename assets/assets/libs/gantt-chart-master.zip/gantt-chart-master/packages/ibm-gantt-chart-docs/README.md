# ibm-gantt-chart-docs

## Documentations and Examples

Documentations and Examples are available as a [Storybook](https://ibm.github.io/gantt-chart/packages/ibm-gantt-chart-docs/storybook)

## Usage

- Start development storybook with `yarn start`
- Build static storybook with `yarn build`
