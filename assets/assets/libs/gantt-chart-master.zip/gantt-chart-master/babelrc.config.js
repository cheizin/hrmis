module.exports = {
  extends: 'gda-scripts/config/.babelrc.js',
};
