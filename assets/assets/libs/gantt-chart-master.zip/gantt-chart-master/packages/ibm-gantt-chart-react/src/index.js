export GanttChart from './components/GanttChart/GanttChart';

export const version = VERSION;
// console.log(`[LOADED] ${NAME}@${VERSION}`);
