# ibm-gantt-chart-dev

Development Environment for Gantt Chart Library.

### Usage

1. Start dev examples with `yarn start`

1. Open https://localhost:8080/ or directly https://localhost:8080/basic.html

Changes in [ibm-gantt-chart](../ibm-gantt-chart) are automatically watched and updated in the running examples.
