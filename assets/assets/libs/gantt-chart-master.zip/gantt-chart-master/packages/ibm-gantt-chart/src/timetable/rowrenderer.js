import Gantt from '../core/core';

const RowRendererPrototype = {
  createShape(activity, parentElt) {
    return parentElt;
  },
};

export default RowRendererPrototype;
