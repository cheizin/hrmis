/* eslint-disable global-require */

module.exports = [require('./webpack.config.lib'), require('./webpack.config.lib.min')];
