console.log(`[LOADED] ${NAME}@${VERSION}`);
