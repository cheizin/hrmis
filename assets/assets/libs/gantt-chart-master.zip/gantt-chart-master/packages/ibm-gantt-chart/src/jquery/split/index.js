import './split';
import './split-pane.scss';
