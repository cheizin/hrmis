import ConstraintsGraph from './constraintgraph';

import './constraintgraph.scss';

export default ConstraintsGraph;
