module.exports = require('gda-scripts/config/.prettierrc.js');
