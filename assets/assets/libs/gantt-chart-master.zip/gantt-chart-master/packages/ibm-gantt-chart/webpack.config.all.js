/* eslint-disable global-require */

module.exports = [
  require('./webpack.config.lib'),
  require('./webpack.config.lib.min'),
  require('./webpack.config.jquery'),
  require('./webpack.config.jquery.min'),
];
