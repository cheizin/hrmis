/* eslint-disable import/no-extraneous-dependencies */
module.exports = require('gda-scripts/config/.importsortrc.js');
